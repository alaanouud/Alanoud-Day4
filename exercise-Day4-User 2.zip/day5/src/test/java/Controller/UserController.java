package Controller;


import Model.User;
import com.example.day5.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class UserController {
    ArrayList<User> users = new ArrayList<User>();
    @GetMapping("/get")
    public ArrayList<User> getUsers(){
        return users;
    }
    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid User user, Errors error){
        if(error.hasErrors()){
            String massege= error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(massege));
        }
        users.add(user);
        return ResponseEntity.status(201).body(new ApiResponse("User added"));
    }
    @PutMapping("/update/{index}")
    public ResponseEntity updateUser(@PathVariable int index, @RequestBody @Valid User user, Errors errors){
        if(errors.hasErrors()){
            String massege= errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse((massege)));
        }
        users.set(index,user);
        return ResponseEntity.status(280).body((new ApiResponse("User updated")));
    }
    @DeleteMapping("/delet/{index}")
    public ResponseEntity deletUser(@PathVariable @Valid int index, Errors errors){
        if(errors.hasErrors()){
            String massege = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body((new ApiResponse(massege)));
        }
        users.remove(index);
        return ResponseEntity.status(208).body(new ApiResponse(("User deleted")));
    }
    }


