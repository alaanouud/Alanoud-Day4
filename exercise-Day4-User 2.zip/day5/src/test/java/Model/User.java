package Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class User {
 @NotEmpty(message = "Name can't be Empty")
 @Size(min =4, max=10, message = "name should be more than 4 less than 10 letters")
 private String name;
 @NotEmpty(message = "Password can't be Empty")
 @Size(min = 4, max = 8, message = "Should be more than 4 and less than 8")
 //@Pattern()     private String password;
private String password;
}
