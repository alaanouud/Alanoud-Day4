package com.example.dayfour.Model;


import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class Employees {
    @NotEmpty(message = "Id can't be null")
    @Size(min = 2 , message = "Id Length must be more than two!")
    String id;
    @NotEmpty(message = "Name can't be null")
    @Size(min = 4, message = "Name size must be more than four!")
    String name;
    @NotNull(message = "Age can't be null")
    @Min(value = 26,message = "Age must be more than 25")
    int age;
    @AssertFalse(message = "ONLEAVE must be false")
    boolean onLeave;
    @NotNull(message = "Employ Year cant't be null")
    @Min(value = 2000,message = "Employ Year must be more than 2000")
    @Max(value = 2024,message = "Employ Year must be less than 2024")
    int empYear ;
    @NotNull(message = "Annual Leave can't be null")
    @Positive(message = "Annual Leave must be positive")
    int annualLeave;

}


